package frontend.parser.declaration.variable.initval;

import frontend.parser.SyntaxNode;

public interface InitValEle extends SyntaxNode {
}
