package frontend.parser.expression.unaryexp;

import frontend.parser.SyntaxNode;

/**
 * UnaryExp文法基类接口
 */
public interface UnaryExpEle extends SyntaxNode {
}
