package frontend.parser;

public interface SyntaxNode {
    String syntaxOutput();
}
