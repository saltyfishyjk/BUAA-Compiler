package frontend.parser.statement.stmt;

import frontend.parser.SyntaxNode;

public interface StmtEle extends SyntaxNode {
}
