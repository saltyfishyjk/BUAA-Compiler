package frontend.parser.declaration;

import frontend.parser.SyntaxNode;

public interface DeclEle extends SyntaxNode {
}
