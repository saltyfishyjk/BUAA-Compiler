package frontend.parser.declaration.variable.vardef;

import frontend.parser.SyntaxNode;

public interface VarDefEle extends SyntaxNode {
}
