package frontend.parser.function.functype;

import frontend.parser.SyntaxNode;

public interface FuncTypeEle extends SyntaxNode {
}
