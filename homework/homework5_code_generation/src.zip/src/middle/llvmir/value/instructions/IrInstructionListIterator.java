package middle.llvmir.value.instructions;

/**
 * LLVM IR Instruction 迭代器
 */
public class IrInstructionListIterator {
}
