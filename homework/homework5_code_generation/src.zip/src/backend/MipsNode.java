package backend;

import java.util.ArrayList;

public interface MipsNode {
    ArrayList<String> mipsOutput();
}
