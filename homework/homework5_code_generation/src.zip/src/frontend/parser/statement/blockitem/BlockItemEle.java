package frontend.parser.statement.blockitem;

import frontend.parser.SyntaxNode;

public interface BlockItemEle extends SyntaxNode {
    int checkReturn();
}
