package frontend.parser.declaration.constant.constinitval;

import frontend.parser.SyntaxNode;

public interface ConstInitValEle extends SyntaxNode {
}
