package middle.llvmir.value;

import java.util.ArrayList;

public interface IrNode {
    ArrayList<String> irOutput();
}
