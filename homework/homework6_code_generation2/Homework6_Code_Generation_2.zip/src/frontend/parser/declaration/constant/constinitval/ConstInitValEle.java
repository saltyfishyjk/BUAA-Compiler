package frontend.parser.declaration.constant.constinitval;

import frontend.parser.SyntaxNode;
import middle.symbol.ValNode;

public interface ConstInitValEle extends SyntaxNode, ValNode {
}
